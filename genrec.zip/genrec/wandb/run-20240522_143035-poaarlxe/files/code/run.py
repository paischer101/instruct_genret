import yaml
import argparse
from ID_generation.preprocessing.data_process import preprocessing
from ID_generation.generate_id import train
from TIGER.training import train_tiger
import torch
import requests
import os

def download_file(url, path):
    response = requests.get(url)
    if response.status_code == 200:
        with open(path, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded {os.path.basename(path)}")
    else:
        print(f"Failed to download {os.path.basename(path)}")

def setup_logging(config):
    if config["logging"]["writer"] == "tensorboard":
        from torch.utils.tensorboard import SummaryWriter
        writer = SummaryWriter(log_dir=f"./logs/tiger_exp{config['exp_id']}")
    elif config["logging"]["writer"] == "wandb":
        from utils import WandbManager
        writer = WandbManager()
        writer.setup(config)
    else:
        raise NotImplementedError("Specified writer not recognized!")
    return writer

if __name__ == "__main__":
    urls = [
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Beauty_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Toys_and_Games_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Sports_and_Outdoors_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Sports_and_Outdoors.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Toys_and_Games.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Beauty.json.gz"
    ]
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='./configs/Sports_and_Outdoors0.yaml', help='Path to the config file.')
    parser.add_argument('--device', type=str, default='cuda:0', help='device to use for training. Default is cuda:0.')
    args = parser.parse_args()
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    print(config)
    device = torch.device(args.device)
    directory = "./ID_generation/preprocessing/raw_data/"
    directory_processed = "./ID_generation/preprocessing/processed/"
    os.makedirs(directory, exist_ok=True)
    os.makedirs(directory_processed, exist_ok=True)
    os.makedirs("./ID_generation/ID/", exist_ok=True)
    os.makedirs("./logs", exist_ok=True)
    os.makedirs("./results", exist_ok=True)
    for url in urls:
        # Extract the filename from the URL
        filename = url.split("/")[-1]
        filepath = os.path.join(directory, filename)
        if not os.path.exists(filepath):
            print(f"{filename} not found, downloading...")
            download_file(url, filepath)
    preprocessing(config['dataset'], config['data_type'])
    writer = setup_logging(config)
    if not os.path.exists(f'./ID_generation/ID/{config["saved_id_path"]}'):
        print("Semantic ID file not found, Training RQ-VAE model...")
        train(config['dataset'], config["saved_id_path"], config['RQ-VAE'], device, writer)

    train_tiger(config['dataset'], config["saved_id_path"], config['TIGER'], device)