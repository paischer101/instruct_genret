import yaml
import argparse
from ID_generation.preprocessing.data_process import preprocessing
from ID_generation.generate_id import train
from TIGER.training import train_tiger
import torch
import requests
import os
import hydra
from omegaconf import DictConfig, OmegaConf

def download_file(url, path):
    response = requests.get(url)
    if response.status_code == 200:
        with open(path, 'wb') as f:
            f.write(response.content)
        print(f"Downloaded {os.path.basename(path)}")
    else:
        print(f"Failed to download {os.path.basename(path)}")

def setup_logging(config):
    if config["writer"] == "tensorboard":
        from torch.utils.tensorboard import SummaryWriter
        writer = SummaryWriter(log_dir=f"./logs/tiger_exp{config['exp_id']}")
    elif config["writer"] == "wandb":
        from utils import WandbManager
        writer = WandbManager()
        writer.setup(config)
    else:
        raise NotImplementedError("Specified writer not recognized!")
    return writer

@hydra.main(version_base=None, config_path="configs", config_name="main")
def main(config: DictConfig) -> None:
    urls = [
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Beauty_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Toys_and_Games_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/reviews_Sports_and_Outdoors_5.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Sports_and_Outdoors.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Toys_and_Games.json.gz",
    "https://snap.stanford.edu/data/amazon/productGraph/categoryFiles/meta_Beauty.json.gz"
    ]
    print(config)
    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    directory = "./ID_generation/preprocessing/raw_data/"
    directory_processed = "./ID_generation/preprocessing/processed/"
    os.makedirs(directory, exist_ok=True)
    os.makedirs(directory_processed, exist_ok=True)
    os.makedirs("./ID_generation/ID/", exist_ok=True)
    os.makedirs("./logs", exist_ok=True)
    os.makedirs("./results", exist_ok=True)
    for url in urls:
        # Extract the filename from the URL
        filename = url.split("/")[-1]
        filepath = os.path.join(directory, filename)
        if not os.path.exists(filepath):
            print(f"{filename} not found, downloading...")
            download_file(url, filepath)
    preprocessing(config['dataset']['name'], config['dataset']['type'])
    writer = setup_logging(dict(config['logging']))
    if not os.path.exists(f'./ID_generation/ID/{config["saved_id_path"]}'):
        print("Semantic ID file not found, Training RQ-VAE model...")
        train(config['dataset'], device, writer)

    train_tiger(config['dataset'], device)

if __name__ == "__main__":
    main()